//
//  TestRootViewController.h
//  DriftAudioSdk
//
//  Created by raymon_wang on 14-11-10.
//  Copyright (c) 2014年 wang3140@hotmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestRootViewController : UIViewController <UIImagePickerControllerDelegate>

@end
